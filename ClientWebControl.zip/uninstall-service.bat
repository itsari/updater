@echo off
setlocal

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Requesting administrator privileges...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set APP_PATH="%~dp0ClientWebControl.exe"

if not exist %APP_PATH% (
    echo ClientWebControl.exe was not found in the same folder as this script.
    exit /b 1
)

rem Stop the service if it is running
sc query ClientWebControlService >nul 2>nul
if not errorlevel 1 (
    sc stop ClientWebControlService >nul 2>nul
)

rem Uninstall the service
%APP_PATH% /uninstall
if errorlevel 1 (
    echo Failed to uninstall the service.
    exit /b 1
)

echo Service uninstalled successfully.
exit /b 0
