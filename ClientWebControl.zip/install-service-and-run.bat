@echo off
setlocal

net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Requesting administrator privileges...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set APP_PATH="%~dp0ClientWebControl.exe"

if not exist %APP_PATH% (
    echo ClientWebControl.exe was not found in the same folder as this script.
    exit /b 1
)

rem Install and start the service
%APP_PATH% /install
if errorlevel 1 (
    echo Failed to install the service.
    exit /b 1
)

sc start ClientWebControlService
if errorlevel 1 (
    echo Failed to start the service.
    exit /b 1
)

echo Service installed and started successfully.
exit /b 0
